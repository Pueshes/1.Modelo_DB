"""
creado: franklin puelles nuñez
Paquete para el trabajo con registros acelerograficos de suelo y su accion con edificios
"""

