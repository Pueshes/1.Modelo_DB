import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler

import GroundMotion_lib.edificio as ed
import GroundMotion_lib.funciones as fn


# noinspection PyPep8Naming
class ProcessingObject:
    """
    Objeto con metodos para el procesamiento de una lista de objetos de edificios
    """

    def __init__(self, edificios = None, range_suelo = (0, 1), range_edificio = (0, 1),
                 range_niveles = (0, 1)):
        self.edificios = edificios

        self.edificiosTrain = None
        self.edificiosTest = None

        self.shapeSuelo = None
        self.shapeNiveles = None

        self.scalerSuelo = MinMaxScaler()
        self.scalerEdificio = MinMaxScaler()
        self.scalerNiveles = MinMaxScaler()

        self.rangeSuelo = range_suelo
        self.rangeEdificio = range_edificio
        self.rangeNiveles = range_niveles

    @property
    def rangeSuelo(self):
        return self.scalerSuelo.feature_range

    @rangeSuelo.setter
    def rangeSuelo(self, range_suelo: tuple):
        self.scalerSuelo.feature_range = range_suelo

    @property
    def rangeEdificio(self):
        return self.scalerEdificio.feature_range

    @rangeEdificio.setter
    def rangeEdificio(self, range_edificio: tuple):
        self.scalerEdificio.feature_range = range_edificio

    @property
    def rangeNiveles(self):
        return self.scalerNiveles.feature_range

    @rangeNiveles.setter
    def rangeNiveles(self, range_niveles: tuple):
        self.scalerNiveles.feature_range = range_niveles

    def get_edi_by_tipo(self, tipo):
        tipo = tipo.upper()

        if tipo == 'TODO':
            return self.edificios
        elif tipo == 'TRAIN':
            return self.edificiosTrain
        elif tipo == 'TEST':
            return self.edificiosTest
        else:
            raise ValueError('Solo se puede usar como tipo {"todo","train", ""test}')

    def _controlerror_existe_edificio(self, texto = 'Aun no se agregan edificios', tipo = 'todo'):
        """
        Controla si es que se han agregado objetos de edificio al atributo adificios, en caso no se haya
        agregado edificios lanza un error con el texto.

        Parameters:
        ----------
        texto: str
            texto que sale como mensaje juto al error de edificios
        Returns
        -------
            None
        """
        tipo = tipo.upper()

        variable_verificar = self.get_edi_by_tipo(tipo)

        if variable_verificar is None:
            raise ValueError(texto)

    def _obtener_tipo_data(self, tipo):
        tipo = tipo.upper()
        self._controlerror_existe_edificio(tipo = tipo)
        data_fit = self.get_edi_by_tipo(tipo)
        return data_fit

    def agregar_edificios(self, edificios: list or tuple or np.ndarray):
        """
        Agrega el argumento edificios al atributo del objeto edificios y calcula cual debe ser los shape para cada
        tipo de datos

        Parameters:
        ----------
        edificios: lilst or tuple or np.ndarray
            debe contener objetos GroundMotion.edificio.Edificio

        Returns:
        -------
            Retorna los edificios guardados en un array
        """
        self.edificios: np.ndarray = fn.controlerror_listtuple_toarray(edificios)
        self.get_shape_data_suelo()
        self.get_shape_data_niveles()

        return self.edificios

    def get_shape_data_suelo(self, tipo = 'todo'):
        """
        Calcula el shape mas grande de la data de suelos de los edificios que se encuentran en el atributo edificios


        Returns:
        -------
            Devuelve el shape en forma de lista de 2 dimensiones
            [2 direcciones, n Punto Max de suelo]

        """
        tipo_edificio = self._obtener_tipo_data(tipo)

        listNPuntosSuelo = list(map(lambda edificio: edificio.sueloNPuntosAcel, tipo_edificio))
        nPuntosMaxSuelo = max(listNPuntosSuelo)
        self.shapeSuelo = [2, nPuntosMaxSuelo]
        return self.shapeSuelo

    def get_shape_data_niveles(self, tipo = 'todo'):
        """
        Calcula el shape mas grande de la data de niveles de los edificios que se encuentran en el atributo edificios


        Returns:
        -------
            Devuelve el shape en forma de lista de 3 dimensiones
            [n pisos maximos que tiene, 2dirreciones, n puntos max]

        """
        tipo_edificio = self._obtener_tipo_data(tipo)

        listNPuntosNiveles = list(map(lambda edificio: edificio.nivelesNPuntosEspec, tipo_edificio))
        listNPisos = list(map(lambda edificio: edificio.nPisos, tipo_edificio))

        nPuntosMaxNiveles = max(listNPuntosNiveles)
        NPisosMax = max(listNPisos)

        self.shapeNiveles = [NPisosMax, 2, nPuntosMaxNiveles]

        return self.shapeNiveles

    def data_for_fit_suelo(self, tipo = 'todo'):
        data_fit = self._obtener_tipo_data(tipo)

        listaDataEdificios = list(map(lambda edificio: edificio.sueloRegacelData.flatten(), data_fit))
        datosConcatenados = np.concatenate(listaDataEdificios)

        datosConcatenados = datosConcatenados.reshape(-1, 1)

        return datosConcatenados

    def data_for_fit_edificio(self, tipo = 'todo'):
        data_fit = self._obtener_tipo_data(tipo)

        listaDataEdificios = list(map(lambda edificio: edificio.ediData, data_fit))
        datosConcatenados = np.stack(listaDataEdificios)

        return datosConcatenados

    def data_for_fit_niveles(self, tipo = 'todo'):
        data_fit = self._obtener_tipo_data(tipo)

        listaDataEdificios = list(map(lambda edificio: edificio.nivelesRegacelData.flatten(), data_fit))
        datosConcatenados = np.concatenate(listaDataEdificios)

        datosConcatenados = datosConcatenados.reshape(-1, 1)

        return datosConcatenados

    def fit_scaler_suelo(self, tipo = 'todo'):
        datos_to_fit = self.data_for_fit_suelo(tipo = tipo)
        self.scalerSuelo.fit(datos_to_fit)

        return self.scalerSuelo

    def fit_scaler_edificio(self, tipo = 'todo'):
        datos_to_fit = self.data_for_fit_edificio(tipo = tipo)
        self.scalerEdificio.fit(datos_to_fit)

        return self.scalerEdificio

    def fit_scaler_niveles(self, tipo = 'todo'):
        datos_to_fit = self.data_for_fit_niveles(tipo = tipo)
        self.scalerNiveles.fit(datos_to_fit)

        return self.scalerNiveles

    def fit_all(self, tipo = 'todo'):
        self.fit_scaler_suelo(tipo = tipo)
        self.fit_scaler_edificio(tipo = tipo)
        self.fit_scaler_niveles(tipo = tipo)

    def train_test_split_edificio(self, test_size = None, train_size = None,
                                  random_state = None, shuffle = True, stratify = None):
        """
        Divide el array del atributo edificios en edificios train y edificios test, ambos se guardan en los atributos
        llamados edificiosTrain y edificiosTest

    Parameters:
    ----------

    test_size : float or int, default=None
        If float, should be between 0.0 and 1.0 and represent the proportion
        of the dataset to include in the test split. If int, represents the
        absolute number of test samples. If None, the value is set to the
        complement of the train size. If ``train_size`` is also None, it will
        be set to 0.25.

    train_size : float or int, default=None
        If float, should be between 0.0 and 1.0 and represent the
        proportion of the dataset to include in the train split. If
        int, represents the absolute number of train samples. If None,
        the value is automatically set to the complement of the test size.

    random_state : int, RandomState instance or None, default=None
        Controls the shuffling applied to the data before applying the split.
        Pass an int for reproducible output across multiple function calls.
        See :term:`Glossary <random_state>`.

    shuffle : bool, default=True
        Whether or not to shuffle the data before splitting. If shuffle=False
        then stratify must be None.

    stratify : array-like, default=None
        If not None, data is split in a stratified fashion, using this as
        the class labels.
        Read more in the :ref:`User Guide <stratification>`.

    Returns:
    -------
    (self.edificiosTrain, self.edificiosTest)


    """
        self.edificiosTrain, self.edificiosTest = train_test_split(self.edificios, test_size = test_size,
                                                                   train_size = train_size, random_state = random_state,
                                                                   shuffle = shuffle, stratify = stratify)

        return self.edificiosTrain, self.edificiosTest

    def processing_suelo(self, objeto_edificio: ed.Edificio):
        """
        Procesa los datos del suelo para 1 edificios siguiendo los siguientes pasos
        completa con 0s hasta llegar al shape de suelos maximo encontrados en todos los edificios agregando un -1
        al inicio

        Parameters:
        ----------
        objeto_edificio: ed.edificios
            objeto edificio con datos de suelo

        Returns:
        -------
            Data de suelo tranformado

        """
        dataSuelo = objeto_edificio.sueloRegacelData

        # primero llenar de 0s
        dataSueloCeros = fn.completar_zeros(dataSuelo, self.shapeSuelo)
        # aplanar array para transofrmar
        dataSueloFlatten = dataSueloCeros.flatten().reshape(-1, 1)
        # Escalamos con MaxMinScales
        dataSueloTransform: np.ndarray = self.scalerSuelo.transform(dataSueloFlatten)
        # Volver al tamaño normal
        dataSueloEnrolladoTransform = dataSueloTransform.reshape(self.shapeSuelo)

        return dataSueloEnrolladoTransform

    def inverse_processing_suelo(self, data_suelo: np.ndarray):
        dataSueloFlatten = data_suelo.flatten()
        dataInverseScale: np.ndarray = self.scalerSuelo.inverse_transform(dataSueloFlatten)
        dataInverseEnrrollado = dataInverseScale.reshape(self.shapeSuelo)

        return dataInverseEnrrollado

    def processing_data_edificio(self, objeto_edificio: ed.Edificio):
        dataEdi = objeto_edificio.ediData
        # Escalamos con MaxMinScaler
        dataEdiTransform: np.ndarray = self.scalerEdificio.transform(dataEdi.reshape(1, -1))

        return dataEdiTransform

    def inverse_processing_data_edificio(self, data_edi: np.ndarray):
        data_edi_inverse = self.scalerEdificio.inverse_transform(data_edi.reshape(1, -1))

        return data_edi_inverse

    def processing_niveles(self, objeto_edificio: ed.Edificio):
        dataNiveles = objeto_edificio.nivelesEspecAcelData

        # primero llenar de 0s
        dataSueloCeros = fn.completar_zeros(dataNiveles, self.shapeSuelo)
        # aplanar array para transofrmar
        dataSueloFlatten = dataSueloCeros.flatten().reshape(-1, 1)
        # Escalamos con MaxMinScales
        dataSueloTransform: np.ndarray = self.scalerSuelo.transform(dataSueloFlatten)
        # Volver al tamaño normal
        dataSueloEnrolladoTransform = dataSueloTransform.reshape(self.shapeSuelo)

        return dataSueloEnrolladoTransform

    def inverse_processing_niveles(self, data_niveles: np.ndarray):
        dataNivelesFlatten = data_niveles.flatten()
        dataInverseScale: np.ndarray = self.scalerNiveles.inverse_transform(dataNivelesFlatten)
        dataInverseEnrrollado = dataInverseScale.reshape(self.shapeNiveles)

        return dataInverseEnrrollado

    def processing_all_data_edificio(self, edificio):
        data_processed_suelo = self.processing_suelo(edificio)
        data_processed_edificio = self.processing_data_edificio(edificio)
        data_processed_niveles = self.processing_niveles(edificio)

        return data_processed_suelo, data_processed_edificio, data_processed_niveles

    def processing_all_edificios(self, edificios_list):
        list_data_processed_suelo = list(map(self.processing_suelo, edificios_list))
        data_processed_suelo = np.stack(list_data_processed_suelo)

        list_data_processed_edificio = list(map(self.processing_data_edificio, edificios_list))
        data_processed_edificio = np.stack(list_data_processed_edificio)

        list_data_processed_niveles = list(map(self.processing_niveles, edificios_list))
        data_processed_niveles = np.stack(list_data_processed_niveles)

        return data_processed_suelo, data_processed_edificio, data_processed_niveles

#
# class ModeloTF:
#
#     def __init__(self):
#         self.modelSuelo = None
#         self.modelEdi = None
#         self.modelGeneral = None
#
#     def _asignar_modelo_atributo(self, modelo, atributo_guardar):
#
#         atributo_guardar = atributo_guardar.upper()
#         if atributo_guardar == 'GENERAL':
#             self.modelGeneral = modelo
#         elif atributo_guardar == 'SUELO':
#             self.modelSuelo = modelo
#         elif atributo_guardar == 'EDIFICIO':
#             self.modelEdi = modelo
#         else:
#             raise ValueError('Solo se puede usar GENERAL, SUELO O EDIFICIO PARA GUARDAR EL MODELO EN EL OBJETO')
#
#     def conv_model(self, input_layer_shape: list or tuple,
#                    conv_layers: list or tuple = ([32, 3, 'relu'], [32, 3, 'relu']),
#                    permute: list or tuple = None,
#                    model_save: str = 'general'):
#
#         input_layer = layers.Input(shape = input_layer_shape, name = 'Input Layer')
#
#         if permute is not None:
#             convCapas = layers.Permute(permute)(input_layer)
#         else:
#             convCapas = input_layer
#
#         for layer_data in conv_layers:
#             filters = layer_data[0]
#             kernel_size = layer_data[1]
#             activation = layer_data[2]
#             convCapas = layers.Conv1D(filters, kernel_size, activation = activation)(convCapas)
#             convCapas = layers.MaxPool1D(pool_size = 2)(convCapas)
#
#         convModel = Model(inputs= input_layer, outputs= convCapas)
#
#         self._asignar_modelo_atributo(convModel, model_save)
#
#         return convModel
#
#
# modelos = ModeloTF()
#
# modeloConvolucional = modelos.conv_model(input_layer_shape = (2, 1200), permute = (2, 1),
#                                          conv_layers = [[64, 3, 'relu'], [128, 3, 'relu'], [128, 3, 'relu']])
