class Saver:

    def serie_ga(self):
        pass
