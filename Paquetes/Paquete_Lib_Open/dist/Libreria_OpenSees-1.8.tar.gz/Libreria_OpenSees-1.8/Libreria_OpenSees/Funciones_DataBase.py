# -*- coding: utf-8 -*-
"""
Created on Mon Mar  8 12:12:07 2021

@author: Franklin
"""

import pandas as pd
import numpy as np
import os




###################################################################
def get_TS_Sis (DB, Path_DB='', tipo='DataFrame',
                PATH_DIR_SIS= 'PATH_DIR_SIS',
                DeltaT='DT',
                N_SIS='N_SIS',
                DIRECCION= 'DIRECCION'):
    """
    Función aplicable a un data frame de sismos para obtener
    sus series de tiempo en forma de array o pd.Series.

    Parameters
    ----------
    DB : DataFrame
        DataFrame con los datos de sismos
    Path_DB : str, optional
        Ruta con la carpeta donde se encuentran las
        bases de datos. The default is ''.
    tipo : str, optional
        Indica el tipo de output, si es DataFrame o Array
        . The default is 'DataFrame'.
    PATH_DIR_SIS : str, optional
        Nombre de la columna del data frame donde se encuentran los GM
        . The default is 'PATH_DIR_SIS'.
    DT : str, optional
        Nombre de la columna del data frame que posee los DT de cada GM
        . The default is 'DT'.
    N_SIS : str, optional
        Nombre de la columna del data frame que posee el número de GM
        . The default is 'N_SIS'.
    DIRECCION : str, optional
        Nombre de la columna del data frame que posee la dirrecion de GM
        . The default is 'DIRECCION'.
    Returns
    -------
    Time_series : array o DataFrame, dependiendo de Tipo
        Traen los registros sismicos desde un file determinado

    """


    Path= os.path.join(Path_DB, DB[PATH_DIR_SIS])
    DT= DB[DeltaT]

    if tipo == 'DataFrame':
        name= '{}- {}'.format(DB[N_SIS],DB[DIRECCION])
        Time_series= pd.read_csv(Path, names=[name])
        long= len(Time_series)
        Time_series.index= np.arange(long)* DT

    elif tipo == 'Array':
        Time_series= pd.read_csv(Path)
        Time_series= np.array(Time_series)
        long= len(Time_series)
        index= np.arange(long) * DT
        Time_series= np.insert(Time_series, 0, index, axis=1)

    return Time_series
