from setuptools import setup

setup(

	name='Libreria_OpenSees',
	version='1.11',
	description='Paquete con funciones utiles para la edicion de codigos de OpenSees, y textos en generales. Como registros sismicos',
	author='Franklin Puelles Nuñez',
	author_email='franklinmpg03@gmail.com',
	packages=['Libreria_OpenSees']

	)

# Para instalar ir a la carpeta con cmd y ejecutar los siguientes comandos
# pip install (nombre del paquete,'Libreria_OpenSees')
# pip3 install (nombre del paquete,'Libreria_OpenSees')

# Para desinstalar
# pip3 uninstall nombre libreria
